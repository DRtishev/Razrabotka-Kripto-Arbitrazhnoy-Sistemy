"""
dex_connector
=============

This connector queries DEX aggregators (e.g. 1inch, OpenOcean) for
swap quotations and broadcasts the results to Kafka.  In addition to
single‑size quotes it can sample multiple trade sizes to estimate
liquidity depth and slippage.  When running in an environment
without internet access the connector emits simulated quotes for
testing purposes.
"""

import os
import asyncio
import json
import logging
from typing import List, Dict, Tuple

import aiohttp
from aiokafka import AIOKafkaProducer

logger = logging.getLogger(__name__)


class AggregatorClient:
    """Client for querying DEX aggregators.

    This implementation supports 1inch v5 and OpenOcean v4.  Calls are
    performed asynchronously.  In environments where outbound HTTP
    calls are not permitted the client generates dummy responses to
    allow downstream components to function.
    """

    def __init__(self, session: aiohttp.ClientSession):
        self.session = session

    async def get_1inch_quote(self, chain_id: str, from_token: str, to_token: str, amount: int) -> Dict[str, object]:
        url = f"https://api.1inch.io/v5.0/{chain_id}/quote"
        params = {
            "fromTokenAddress": from_token,
            "toTokenAddress": to_token,
            "amount": str(amount)
        }
        try:
            async with self.session.get(url, params=params, timeout=5) as resp:
                return await resp.json()
        except Exception as e:
            logger.warning("HTTP error calling 1inch: %s", e)
            # Emit a simulated quote if network is unavailable
            return {
                "protocol": "1inch",
                "error": str(e),
                "toTokenAmount": str(int(amount * 0.99)),
                "estimatedGas": 200000
            }

    async def get_openocean_quote(self, chain: str, from_token: str, to_token: str, amount: int) -> Dict[str, object]:
        url = f"https://open-api.openocean.finance/v4/{chain}/quote"
        params = {
            "inTokenAddress": from_token,
            "outTokenAddress": to_token,
            "amount": str(amount)
        }
        try:
            async with self.session.get(url, params=params, timeout=5) as resp:
                return await resp.json()
        except Exception as e:
            logger.warning("HTTP error calling OpenOcean: %s", e)
            return {
                "protocol": "openocean",
                "error": str(e),
                "data": {
                    "outAmount": str(int(amount * 0.985)),
                    "estimatedGas": 250000
                }
            }

    async def get_1inch_fusion_quote(self, from_chain: str, to_chain: str, from_token: str, to_token: str, amount: int) -> Dict[str, object]:
        """Simulate a cross‑chain quote using 1inch Fusion+.

        In Fusion+, users sign an intent off‑chain and resolvers compete to
        fill it across chains without requiring a bridge.  Because this
        environment does not permit outbound HTTP requests, we return a
        fabricated quote that reduces the amount by a small fee and
        includes indicative execution details.  Replace this logic with
        calls to the 1inch Fusion+ API when network access is available【369577708175767†L159-L177】.

        Args:
            from_chain: source chain identifier (e.g. "ethereum")
            to_chain: destination chain identifier (e.g. "solana")
            from_token: token address on the source chain
            to_token: token address on the destination chain
            amount: amount of from_token to swap (in minimal units)

        Returns:
            A dict with fields similar to 1inch API responses.
        """
        # For demonstration: 0.3% fee and static gas; real API will provide
        # more precise numbers and estimated fees per chain
        fee_rate = 0.003
        out_amount = int(amount * (1 - fee_rate))
        return {
            "protocol": "1inch_fusion",
            "fromChain": from_chain,
            "toChain": to_chain,
            "fromToken": from_token,
            "toToken": to_token,
            "fromAmount": str(amount),
            "toAmount": str(out_amount),
            "fee": str(int(amount * fee_rate)),
            "resolverFeePaid": True,
            "estimatedTime": 30  # seconds
        }

    async def get_fusion_plus_quote(
        self,
        src_chain: str,
        dest_chain: str,
        src_token: str,
        dest_token: str,
        amount: int,
        preset: str = "auto",
        slippage_bps: int = 50,
    ) -> Dict[str, object]:
        """
        Return a simulated cross‑chain quote using the intent‑based 1inch Fusion+ API.

        Fusion+ is 1inch's next‑generation cross‑chain swap protocol.  Unlike
        traditional bridges, it executes swaps atomically across chains
        without any custodial intermediaries: users sign an off‑chain intent,
        resolvers compete in a Dutch auction to fill the order and pay the
        gas on both chains, so the swap is essentially gas‑free for the
        end user【369577708175767†L159-L177】【684671458501765†L96-L118】.  In August 2025 the
        protocol was expanded to support Solana alongside twelve EVM networks,
        enabling direct swaps between Solana and EVM chains with no bridges
        involved【369577708175767†L159-L177】.  All orders are self‑custodial and
        protected from MEV by default【684671458501765†L96-L118】.

        This method fabricates a quote based on the input amount and a
        preset‑specific fee because our test environment cannot reach the
        public Fusion+ API.  The ``preset`` parameter (``auto``, ``fast``,
        ``fair`` or ``custom``) influences the simulated fee and execution
        time.  When internet access is available, this function should
        call the official 1inch Fusion+ Quoter endpoint and return the
        actual resolver response.

        Args:
            src_chain: Human‑readable name of the source chain (e.g. ``ethereum``).
            dest_chain: Name of the destination chain (e.g. ``solana``).
            src_token: Token contract address on the source chain.
            dest_token: Token contract address on the destination chain.
            amount: Amount of src_token to swap (in the smallest units).
            preset: Fusion+ execution preset; one of ``auto``, ``fast``, ``fair`` or ``custom``.
            slippage_bps: Maximum acceptable slippage in basis points (1 basis
                point = 0.01%).

        Returns:
            A dictionary mimicking the structure of a Fusion+ quote.  When
            network access is available this should match the response from
            1inch's Fusion+ Quoter API.
        """
        # Determine a notional fee based on preset.  Faster presets pay higher
        # fees to resolvers but achieve lower latency.  In a real integration
        # these values would be returned by the 1inch API along with gas and
        # resolver compensation.
        base_fee_rate = 0.002  # 0.2% base fee
        preset_multiplier = {
            "auto": 1.0,
            "fast": 1.5,
            "fair": 1.2,
            "custom": 1.0,
        }.get(preset, 1.0)
        fee_rate = base_fee_rate * preset_multiplier
        out_amount = int(amount * (1 - fee_rate))
        estimated_time = {
            "auto": 45,
            "fast": 20,
            "fair": 60,
            "custom": 40,
        }.get(preset, 45)
        return {
            "protocol": "1inch_fusion_plus",
            "srcChain": src_chain,
            "destChain": dest_chain,
            "srcToken": src_token,
            "destToken": dest_token,
            "srcAmount": str(amount),
            "destAmount": str(out_amount),
            "preset": preset,
            "slippageBps": slippage_bps,
            "resolverFeePaid": True,
            "estimatedTime": estimated_time,
            "simulated": True,
        }


async def sample_quotes(
    client: AggregatorClient,
    chain_id: str,
    chain_name: str,
    from_token: str,
    to_token: str,
    sizes: List[int]
) -> List[Tuple[str, Dict[str, object]]]:
    """Query both aggregators for each size.

    Returns a list of (aggregator_name, quote_json) tuples.
    """
    results = []
    for amount in sizes:
        q1 = await client.get_1inch_quote(chain_id, from_token, to_token, amount)
        results.append(("1inch", q1))
        q2 = await client.get_openocean_quote(chain_name, from_token, to_token, amount)
        results.append(("openocean", q2))
    return results


async def run_producer():
    # Configure logging level from environment
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(level=getattr(logging, log_level, logging.INFO))

    kafka_bootstrap = os.getenv("KAFKA_BOOTSTRAP", "localhost:9092")
    chain_id = os.getenv("CHAIN_ID", "1")
    chain_name = os.getenv("CHAIN_NAME", "ethereum")
    from_token = os.getenv("FROM_TOKEN", "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
    to_token = os.getenv("TO_TOKEN", "0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48")  # USDC
    sizes_str = os.getenv("TRADE_SIZES", "1000000000000000000,5000000000000000000")
    sizes = [int(x) for x in sizes_str.split(",") if x]
    dest_chain = os.getenv("CROSS_TO_CHAIN", "")
    fusion_preset = os.getenv("FUSION_PRESET", "auto")
    fusion_slippage_bps = int(os.getenv("FUSION_SLIPPAGE_BPS", "50"))

    producer = AIOKafkaProducer(bootstrap_servers=kafka_bootstrap)
    await producer.start()
    logger.info("DEX connector started; publishing to Kafka at %s", kafka_bootstrap)
    try:
        async with aiohttp.ClientSession() as session:
            client = AggregatorClient(session)
            while True:
                quotes = await sample_quotes(client, chain_id, chain_name, from_token, to_token, sizes)
                # Publish regular single‑chain quotes
                for agg, quote in quotes:
                    msg = {
                        "aggregator": agg,
                        "chain": chain_name,
                        "pair": f"{from_token[:6]}/{to_token[:6]}",
                        "quote": quote
                    }
                    topic = f"market.dex.quote.{agg}.{chain_name}.{from_token[:6]}_{to_token[:6]}"
                    await producer.send_and_wait(topic, json.dumps(msg).encode())
                    logger.debug("Published quote to %s", topic)
                # If cross‑chain destination is configured, publish both simple Fusion and
                # Fusion+ quotes.  The original 1inch Fusion quote simulates a cross‑chain
                # order without presets, while Fusion+ adds presets and slippage control.
                if dest_chain and dest_chain != chain_name:
                    for amount in sizes:
                        # Legacy Fusion (simple intent) quote
                        fusion_quote = await client.get_1inch_fusion_quote(
                            chain_name, dest_chain, from_token, to_token, amount
                        )
                        msg_simple = {
                            "aggregator": "fusion",
                            "fromChain": chain_name,
                            "toChain": dest_chain,
                            "pair": f"{from_token[:6]}/{to_token[:6]}",
                            "quote": fusion_quote
                        }
                        topic_simple = f"market.dex.quote.fusion.{chain_name}.{dest_chain}.{from_token[:6]}_{to_token[:6]}"
                        await producer.send_and_wait(topic_simple, json.dumps(msg_simple).encode())
                        logger.debug("Published cross‑chain quote to %s", topic_simple)
                        # Fusion+ quote with presets and slippage
                        fusion_plus_quote = await client.get_fusion_plus_quote(
                            chain_name, dest_chain, from_token, to_token, amount,
                            preset=fusion_preset, slippage_bps=fusion_slippage_bps
                        )
                        msg_plus = {
                            "aggregator": "fusion_plus",
                            "srcChain": chain_name,
                            "destChain": dest_chain,
                            "pair": f"{from_token[:6]}/{to_token[:6]}",
                            "quote": fusion_plus_quote
                        }
                        topic_plus = f"market.dex.quote.fusionplus.{chain_name}.{dest_chain}.{from_token[:6]}_{to_token[:6]}"
                        await producer.send_and_wait(topic_plus, json.dumps(msg_plus).encode())
                        logger.debug("Published Fusion+ quote to %s", topic_plus)
                await asyncio.sleep(float(os.getenv("QUOTE_INTERVAL", "5")))
    finally:
        await producer.stop()


if __name__ == "__main__":
    try:
        asyncio.run(run_producer())
    except KeyboardInterrupt:
        logger.info("DEX connector stopped by user")
