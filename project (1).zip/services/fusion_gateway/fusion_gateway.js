/*
 * fusion_gateway.js
 *
 * A lightweight HTTP gateway built on top of the 1inch Fusion+ SDK.  It exposes
 * three endpoints for quoting, submitting and tracking cross‑chain intent
 * orders.  This code is designed as a starting point: the real 1inch SDK
 * requires a valid API key issued via the 1inch Dev Portal and network
 * connectivity to their Fusion services.  To keep this repository self‑contained
 * and functional in offline environments, the gateway will return simulated
 * responses when it cannot reach the 1inch endpoints.  Replace the stubbed
 * logic with calls to `sdk.getQuote`, `sdk.createOrder` and
 * `sdk.getOrderStatus` from the official SDK once internet access is
 * available【369577708175767†L159-L177】【684671458501765†L96-L118】.
 */

const express = require('express');
const dotenv = require('dotenv');

// Load environment variables from .env file
dotenv.config();

// Attempt to import the 1inch Fusion+ SDK.  In environments without
// internet access or NPM installation this import may fail.  The
// try/catch allows the gateway to fall back to simulated responses.
let FusionSDK;
try {
  ({ FusionSDK } = require('@1inch/cross-chain-sdk'));
} catch (err) {
  console.warn('1inch SDK not found, using simulation mode');
}

const app = express();
app.use(express.json());

/**
 * Obtain a quote for a cross‑chain swap.  The request body should include
 * ``srcChainId`` and ``destChainId`` (as numbers), ``srcToken`` and
 * ``destToken`` (token addresses), ``amount`` (as a decimal string) and
 * ``walletAddress`` (the user initiating the swap).  The optional
 * ``preset`` field selects the execution preset (``auto``, ``fast``,
 * ``fair`` or ``custom``).  When the 1inch SDK is unavailable this
 * endpoint returns a fabricated quote that deducts a small fee and
 * reports an indicative ETA.  See the 1inch documentation for the
 * complete format of a Fusion+ quote【369577708175767†L159-L177】.
 */
app.post('/quote', async (req, res) => {
  const {
    srcChainId,
    destChainId,
    srcToken,
    destToken,
    amount,
    walletAddress,
    preset = 'auto',
  } = req.body;
  // Validate basic parameters
  if (!srcChainId || !destChainId || !srcToken || !destToken || !amount || !walletAddress) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  // If the SDK is available and we have an API key then request a real quote
  if (FusionSDK && process.env.ONE_INCH_DEV_API_KEY) {
    try {
      const sdk = new FusionSDK({
        url: 'https://api.1inch.dev/fusion',
        networkId: Number(srcChainId),
        authKey: process.env.ONE_INCH_DEV_API_KEY,
      });
      const quote = await sdk.getQuote({
        srcChainId: Number(srcChainId),
        destChainId: Number(destChainId),
        fromAddress: walletAddress,
        fromToken: srcToken,
        toToken: destToken,
        amount: amount.toString(),
        preset,
      });
      return res.json(quote);
    } catch (err) {
      console.error('Error fetching Fusion+ quote', err);
      // Fall through to simulation
    }
  }
  // Simulation: apply a 0.25% fee and assign an ETA based on preset
  const numAmount = BigInt(amount);
  const feeRate = {
    auto: 0.0025,
    fast: 0.0035,
    fair: 0.003,
    custom: 0.0025,
  }[preset] || 0.0025;
  const outAmount = BigInt(numAmount * BigInt(10000 - Math.floor(feeRate * 10000)) / BigInt(10000));
  const eta = {
    auto: 45,
    fast: 20,
    fair: 60,
    custom: 40,
  }[preset] || 45;
  return res.json({
    protocol: 'fusion+ simulation',
    srcChainId,
    destChainId,
    srcToken,
    destToken,
    amount: amount.toString(),
    outAmount: outAmount.toString(),
    preset,
    estimatedTime: eta,
    simulated: true,
  });
});

/**
 * Create a Fusion+ order (intent) based on a prior quote.  The request
 * should include ``quoteId`` from the quote response, ``receiver`` (the
 * wallet that will receive the tokens on the destination chain) and
 * optionally ``preset``.  When the SDK is not available this endpoint
 * constructs a pseudo order hash and returns it along with a dummy
 * secret for hashlocking.  Replace this logic with `sdk.createOrder`
 * when network connectivity is available【369577708175767†L159-L177】.
 */
app.post('/order', async (req, res) => {
  const { quoteId, receiver, secret, preset = 'auto' } = req.body;
  if (!quoteId || !receiver) {
    return res.status(400).json({ error: 'Missing quoteId or receiver' });
  }
  if (FusionSDK && process.env.ONE_INCH_DEV_API_KEY) {
    try {
      const sdk = new FusionSDK({
        url: 'https://api.1inch.dev/fusion',
        networkId: 1,
        authKey: process.env.ONE_INCH_DEV_API_KEY,
      });
      const order = await sdk.createOrder({ quoteId, receiver, preset, secret });
      return res.json(order);
    } catch (err) {
      console.error('Error creating Fusion+ order', err);
    }
  }
  // Simulation: fabricate an order hash and secret
  const orderHash = '0x' + Math.random().toString(16).substr(2, 64);
  const secretValue = secret || '0x' + Math.random().toString(16).substr(2, 64);
  return res.json({
    simulated: true,
    orderHash,
    quoteId,
    receiver,
    preset,
    secret: secretValue,
  });
});

/**
 * Query the status of a Fusion+ order.  The client should provide the
 * order hash as a URL parameter.  If the SDK is available this
 * endpoint will query the 1inch API; otherwise it returns a simulated
 * status.  In simulation mode the status cycles through ``pending``,
 * ``resolved`` and ``completed`` on successive calls.
 */
let simulationStatusIndex = 0;
const simulationStatuses = ['pending', 'resolved', 'completed'];
app.get('/status/:hash', async (req, res) => {
  const { hash } = req.params;
  if (!hash) {
    return res.status(400).json({ error: 'Missing order hash' });
  }
  if (FusionSDK && process.env.ONE_INCH_DEV_API_KEY) {
    try {
      const sdk = new FusionSDK({
        url: 'https://api.1inch.dev/fusion',
        networkId: 1,
        authKey: process.env.ONE_INCH_DEV_API_KEY,
      });
      const status = await sdk.getOrderStatus(hash);
      return res.json(status);
    } catch (err) {
      console.error('Error fetching Fusion+ status', err);
    }
  }
  // Simulation: rotate through statuses
  const status = simulationStatuses[simulationStatusIndex % simulationStatuses.length];
  simulationStatusIndex++;
  return res.json({ simulated: true, orderHash: hash, status });
});

const port = parseInt(process.env.PORT || '7070', 10);
app.listen(port, () => {
  console.log(`Fusion+ gateway listening on port ${port}`);
});