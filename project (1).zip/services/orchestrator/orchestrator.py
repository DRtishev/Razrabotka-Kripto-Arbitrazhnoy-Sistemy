"""
orchestrator
============

The orchestrator is responsible for coordinating the execution of
arbitrage opportunities across multiple execution engines.  It
consumes opportunity messages from Kafka topics produced by the
detectors and transforms them into concrete execution plans.  A
plan is executed as a **saga** consisting of one or more legs.  If
any leg fails the orchestrator attempts to run a compensating action
to unwind the partially executed state.  Saga state is persisted
in Redis with a time‑to‑live (TTL) so that crashed or restarted
processes can recover unfinished trades.

This implementation provides a skeleton for the saga orchestration
pattern.  It does not include full error handling or persistence
logic but illustrates how to structure the main loop and
compensating actions.  Production usage should build on this
foundation.  The orchestrator can be extended to handle cross‑chain
opportunities delivered via the 1inch Fusion+ API.  Fusion+ allows
intent‑based atomic swaps between Solana and EVM chains without
bridges; orders are gasless, protected from MEV and self‑custodial
【369577708175767†L159-L177】【684671458501765†L96-L118】.  In such cases the
orchestrator would call out to the fusion_gateway service to
create an order and monitor its status before performing any
hedging trade.  That functionality is left as an exercise for
future development.
"""

import asyncio
import json
import logging
import os
from typing import Dict, List

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
import aioredis

logger = logging.getLogger(__name__)


class Saga:
    """A simple saga managing two legs with optional compensation."""

    def __init__(self, id: str, legs: List[Dict[str, object]], compensation: List[Dict[str, object]]):
        self.id = id
        self.legs = legs
        self.compensation = compensation
        self.current = 0
        self.completed = False
        self.failed = False

    async def execute(self, producer: AIOKafkaProducer) -> bool:
        """Execute the saga legs sequentially.

        Args:
            producer: Kafka producer used to send execution requests.
        Returns:
            True if all legs were executed successfully, False otherwise.
        """
        for idx, leg in enumerate(self.legs):
            logger.info("Saga %s: executing leg %s/%s", self.id, idx + 1, len(self.legs))
            await producer.send_and_wait("exec.request", json.dumps(leg).encode())
            # In a real implementation we would wait for a response on
            # `exec.result` and verify success before proceeding.  Here
            # we simulate immediate success.
            # TODO: listen on exec.result and update status
            success = True
            if not success:
                self.failed = True
                await self._compensate(producer)
                return False
        self.completed = True
        logger.info("Saga %s: all legs executed", self.id)
        return True

    async def _compensate(self, producer: AIOKafkaProducer):
        """Run compensating actions for a failed saga."""
        logger.warning("Saga %s: initiating compensation", self.id)
        for comp in self.compensation:
            await producer.send_and_wait("exec.request", json.dumps(comp).encode())
        logger.info("Saga %s: compensation submitted", self.id)


async def main():
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(level=getattr(logging, log_level, logging.INFO))
    kafka_bootstrap = os.getenv("KAFKA_BOOTSTRAP", "localhost:9092")
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    consumer = AIOKafkaConsumer(
        "arb.opportunity.cex_cex",
        "arb.opportunity.dex_cex",
        "arb.opportunity.dexdex",
        "arb.opportunity.futures",
        bootstrap_servers=kafka_bootstrap,
        group_id="orchestrator"
    )
    producer = AIOKafkaProducer(bootstrap_servers=kafka_bootstrap)
    redis = await aioredis.from_url(redis_url)

    await consumer.start()
    await producer.start()
    logger.info("Orchestrator started; listening for opportunities")
    try:
        async for msg in consumer:
            try:
                payload = json.loads(msg.value.decode())
            except Exception as e:
                logger.error("Invalid JSON in message: %s", e)
                continue
            op_type = msg.topic.split(".")[-1]
            saga_id = payload.get("id") or payload.get("opportunity_id") or "unknown"
            # Persist raw payload to Redis with TTL
            await redis.setex(f"saga:{saga_id}:payload", 3600, msg.value)
            # Build a list of legs depending on opportunity type
            legs = build_legs(op_type, payload)
            compensation = build_compensation(op_type, payload)
            saga = Saga(saga_id, legs, compensation)
            # Store saga state
            await redis.set(f"saga:{saga_id}:state", json.dumps({"status": "pending"}))
            success = await saga.execute(producer)
            await redis.set(f"saga:{saga_id}:state", json.dumps({"status": "completed" if success else "failed"}))
    finally:
        await consumer.stop()
        await producer.stop()
        await redis.close()


def build_legs(op_type: str, payload: Dict[str, object]) -> List[Dict[str, object]]:
    """Construct a list of execution commands based on the opportunity type."""
    if op_type == "cex_cex":
        # Sell asset on exchange A and buy on exchange B
        return [
            {"kind": "cex_order", "exchange": payload["sell_exchange"], "side": "sell", "pair": payload["pair"], "size": payload["size"], "price": payload["sell_price"]},
            {"kind": "cex_order", "exchange": payload["buy_exchange"], "side": "buy", "pair": payload["pair"], "size": payload["size"], "price": payload["buy_price"]}
        ]
    elif op_type in ("dex_cex", "dexdex"):
        # Execute on DEX first then hedge on CEX or second DEX
        return [
            {"kind": "dex_swap", "aggregator": payload.get("aggregator"), "chain": payload.get("chain"), "from_token": payload.get("from_token"), "to_token": payload.get("to_token"), "size": payload.get("size"), "slippage": payload.get("slippage"), "gas_limit": payload.get("estimatedGas")},
            {"kind": "cex_order" if op_type == "dex_cex" else "dex_swap", "exchange": payload.get("hedge_exchange"), "pair": payload.get("pair"), "side": "sell" if op_type == "dex_cex" else None, "size": payload.get("size"), "price": payload.get("hedge_price")}
        ]
    elif op_type == "futures":
        # Hedge funding: open spot position and opposite perp
        return [
            {"kind": "cex_order", "exchange": payload.get("spot_exchange"), "side": "buy", "pair": payload.get("pair"), "size": payload.get("size"), "price": payload.get("spot_price")},
            {"kind": "perp_order", "exchange": payload.get("perp_exchange"), "side": "sell", "symbol": payload.get("symbol"), "size": payload.get("size"), "price": payload.get("perp_price"), "reduce_only": True}
        ]
    else:
        logger.warning("Unknown opportunity type %s", op_type)
        return []


def build_compensation(op_type: str, payload: Dict[str, object]) -> List[Dict[str, object]]:
    """Create compensating commands in case the saga fails."""
    if op_type == "cex_cex":
        # Reverse positions: buy back on sell exchange, sell back on buy exchange
        return [
            {"kind": "cex_order", "exchange": payload["sell_exchange"], "side": "buy", "pair": payload["pair"], "size": payload["size"], "price": payload["sell_price"]},
            {"kind": "cex_order", "exchange": payload["buy_exchange"], "side": "sell", "pair": payload["pair"], "size": payload["size"], "price": payload["buy_price"]}
        ]
    elif op_type in ("dex_cex", "dexdex"):
        # Reverse the initial DEX swap.  This is naive: in practice you
        # would need to compute the correct trade to unwind the
        # position, including gas and slippage.
        return [
            {"kind": "dex_swap", "aggregator": payload.get("aggregator"), "chain": payload.get("chain"), "from_token": payload.get("to_token"), "to_token": payload.get("from_token"), "size": payload.get("size"), "slippage": payload.get("slippage"), "gas_limit": payload.get("estimatedGas")}
        ]
    elif op_type == "futures":
        # Close both spot and perp
        return [
            {"kind": "cex_order", "exchange": payload.get("spot_exchange"), "side": "sell", "pair": payload.get("pair"), "size": payload.get("size"), "price": payload.get("spot_price")},
            {"kind": "perp_order", "exchange": payload.get("perp_exchange"), "side": "buy", "symbol": payload.get("symbol"), "size": payload.get("size"), "price": payload.get("perp_price"), "reduce_only": True}
        ]
    else:
        return []


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Orchestrator shutting down")
