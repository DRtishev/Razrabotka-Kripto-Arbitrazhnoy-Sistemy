"""
mev_adapter
===========

This module provides an interface for submitting Ethereum transactions
via MEV relayers such as Flashbots Protect and SUAVE.  It uses the
`common.eth_signer` module to sign transactions with a private key
loaded from environment variables.  Because this code runs in an
isolated environment, outbound network access may not be available,
so the default `send_bundle` function logs the payload instead of
performing a real HTTP request.

The MEV adapter exposes a single function `submit_transaction` which
takes a transaction dictionary (including calldata, gas limits and
fee parameters) and submits it to the configured relay.  It returns
a status dict containing either a transaction hash or an error
message.  When a private key is not provided the transaction is
returned unmodified and the caller must handle broadcasting it via a
fallback path.
"""

import os
import logging
from typing import Dict, Optional

from ..common import eth_signer


logger = logging.getLogger(__name__)


def submit_transaction(tx: Dict[str, object]) -> Dict[str, object]:
    """Sign and submit a transaction via the configured MEV relay.

    Args:
        tx: An EIP‑1559 transaction dictionary with keys `to`,
            `value`, `data`, `gas`, `maxFeePerGas`,
            `maxPriorityFeePerGas`, `nonce`, and `chainId`.

    Returns:
        A dict with fields: `status` (`ok` or `error`) and
        additional information.  If signing fails because the
        private key is missing, the returned dict will include the
        original `tx` so that the caller can fall back to an
        alternative submission path.
    """
    relay_url = os.getenv("FLASHBOTS_RPC_URL", "")
    private_key = eth_signer.load_private_key()
    if not private_key:
        logger.warning("Private key not available; returning unsigned transaction")
        return {"status": "no_private_key", "tx": tx}

    # Sign the transaction.  This produces a dummy raw transaction if
    # eth_signer.sign_transaction has not been replaced with a real
    # implementation.
    raw_tx = eth_signer.sign_transaction(tx, private_key)
    bundle = {
        "txs": [raw_tx],
        "metadata": {
            "caller": "dex_executor",
            "description": "bundle submitted by DEX executor"
        }
    }
    response = eth_signer.send_flashbots_bundle(bundle, relay_url)
    # Combine the relay response with the raw transaction for traceability
    result = {"status": response.get("status", "unknown"), "message": response.get("message", ""), "raw_tx": raw_tx}
    return result
